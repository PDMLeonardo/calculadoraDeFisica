import kotlin.math.*

class CalculadoraFisica {


    fun forcaPeso(massa:Float,gravidade:Float): Float {
        return massa * gravidade

    }

    fun forcaCentripeta(massa:Float,velocidade:Double,raioDaCurva:Float): Double {
        return massa * (Math.pow(velocidade,2.0) / raioDaCurva)
    }

    fun impulso(forca:Float, tempoFinal:Float, tempoInicial: Float): Float {
        return forca * (tempoFinal - tempoInicial)
    }


    fun forcaElastica(forca:Float, constanteMola:Float, deformacaoMola: Float): Float {
        return forca * (constanteMola - deformacaoMola)
    }

    fun velocidadeMedia(tempoFinal:Float, tempoInicial: Float, posicaoFinal:Float, posicaoInicial: Float  ): Float {
        return (posicaoFinal - posicaoInicial) / (tempoFinal - tempoInicial)
    }

    fun movimentoRetilineoUniformemente(so:Float, velocidade:Double, tempo:Float): Double {
        return so + velocidade * tempo
    }
    fun movimentoRetilineoUniformementeVariado(so:Float, velocidadeO:Double, tempo:Float, aceleracao:Double,t:Double): Double {
        return so + velocidadeO * tempo + Math.pow(t,2.0) / 2
    }
}