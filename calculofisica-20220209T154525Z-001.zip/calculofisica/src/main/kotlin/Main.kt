
fun main() {
    val calculadoraFisica = CalculadoraFisica()

    println("Digite a massa")

    val massa:Float = readLine()!!.toFloat()

    println("Digite a gravidade")

    val gravidade:Float = readLine()!!.toFloat()

    println("Digite a velocidade")

    val velocidade:Double = readLine()!!.toDouble()

    println("Digite o raio da Curva")
    val raioDaCurva:Float = readLine()!!.toFloat()

    println("Digite a força")
    val forca:Float = readLine()!!.toFloat()

    println("Digite o tempo Final")
    val tempoFinal:Float = readLine()!!.toFloat()

    println("Digite o tempo Inicial")
    val tempoInicial:Float = readLine()!!.toFloat()

    println("Digite a constante da mola")
    val constanteMola:Float = readLine()!!.toFloat()

    println("Digite a deformação da mola")
    val deformacaoMola:Float = readLine()!!.toFloat()

    println("Digite a posição Inicial")
    val posicaoInicial:Float = readLine()!!.toFloat()

    println("Digite posiçao Final")
    val posicaoFinal:Float = readLine()!!.toFloat()

    println("Digite so")
    val so:Float = readLine()!!.toFloat()

    println("Digite o tempo")
    val tempo:Float = readLine()!!.toFloat()

    println("Digite a aceleracao")
    val aceleracao:Double = readLine()!!.toDouble()

    println("Digite a velocidadeO")
    val velocidadeO:Double = readLine()!!.toDouble()

    println("Digite o t:")
    val t:Double = readLine()!!.toDouble()






    println("Força Peso: ")


    println("A força F=" + calculadoraFisica.forcaPeso(massa,gravidade))

    println("Força Centrípeta: ")

    println("A força Fcp=" + calculadoraFisica.forcaCentripeta(massa, velocidade, raioDaCurva ))

    println("Impulso: ")

    println("O Impulso I =" + calculadoraFisica.impulso(forca, tempoFinal, tempoInicial ))

    println("Força Elástica: ")

    println("a Força Elastica é F=" + calculadoraFisica.forcaElastica(forca, constanteMola, deformacaoMola))

    println("Velocidade Média: ")

    println("Velocidade Media é Vm= " + calculadoraFisica.velocidadeMedia(tempoFinal, tempoInicial, posicaoFinal, posicaoInicial))

    println("Movimento Retilíneo Uniformemente: ")

    println("MRU é S= "+ calculadoraFisica.movimentoRetilineoUniformemente(so,velocidade,tempo))

    println("Movimento Retilineo Uniformemmente: ")

    println("MRUV é S= " + calculadoraFisica.movimentoRetilineoUniformementeVariado(so, velocidadeO, tempo, aceleracao, t))
}