
rootProject.name = "calculofisica"

